import time
import numpy as np
import pandas as pd
import scipy.io as sio
import scipy.io as sio
import sys
import pickle
from sklearn.model_selection import cross_val_predict
from sklearn.metrics import roc_curve, auc
from sklearn.model_selection import StratifiedKFold
from sklearn.linear_model import ElasticNet, ElasticNetCV
#from RFE_feature_selection import SVM_RFE_selection,LOG_RFE_selection,XGB_selection,LGBM_RFE,GDB_RFE
from sklearn.preprocessing import scale,StandardScaler,minmax_scale,MinMaxScaler,normalize
import utils.tools as utils
import matplotlib.pyplot as plt
from sklearn.ensemble import RandomForestClassifier
import lightgbm
from sklearn.metrics import accuracy_score
sys.path.insert(0, "lib")
from gcforest.gcforest import GCForest
start = time.time()
def get_toy_config():
    config = {}
    ca_config = {}
    ca_config["random_state"] = 21
    ca_config["max_layers"] = 4
    ca_config["early_stopping_rounds"] = 5
    ca_config["n_classes"] = 2
    ca_config["estimators"] = []
    ca_config["estimators"].append(
        {"n_folds": 5, "type": "XGBClassifier", "n_estimators": 5, "max_depth": 4,"num_class":2,
             "objective": "multi:softprob",   "learning_rate": 0.01} )
    ca_config["estimators"].append({"n_folds": 5, "type": "RandomForestClassifier", "n_estimators": 5, "max_depth": 4, "n_jobs": -1})
    ca_config["estimators"].append({"n_folds": 5, "type": "ExtraTreesClassifier", "n_estimators": 5, "max_depth": 4, "n_jobs": -1})
    ca_config["estimators"].append({"n_folds": 5, "type": "LogisticRegression","C":0.1,})
    #ca_config["estimators"].append({"n_folds": 5, "type": "SGDClassifier"})
    #ca_config["estimators"].append({"n_folds":10,"type": "GradientBoostingClassifier", "n_estimators": 100, "max_depth": 5, "n_jobs": -1})

    config["cascade"] = ca_config
    return config
def elasticNet(data,label,alpha): #, 0.002, 0.003,0.004, 0.005, 0.006, 0.007, 0.008,0.009, 0.01])):
    enetCV = ElasticNetCV(alphas=alpha,l1_ratio=0.1).fit(data,label)
    enet=ElasticNet(alpha=enetCV.alpha_, l1_ratio=0.1)
    enet.fit(data,label)
    mask = enet.coef_ != 0
    new_data = data[:,mask]
    return new_data,mask
def training(X, y,gc):
    gc=gc
    X = X
    y = y
    skf= StratifiedKFold(n_splits=10,shuffle=False)
    sepscores = []
    ytest=np.ones((1,2))*0.5
    yscore=np.ones((1,2))*0.5
    for train, test in skf.split(X,y):
        gc_model=gc.fit_transform(X[train], y[train])
        y_score=gc.predict_proba(X[test])
        yscore=np.vstack((yscore,y_score))
        y_test=utils.to_categorical(y[test])
        ytest=np.vstack((ytest,y_test))
        fpr, tpr,_= roc_curve(y_test[:,0], y_score[:,0])
        roc_auc = auc(fpr, tpr)
        y_class= utils.categorical_probas_to_classes(y_score)
        y_test_tmp=y[test]
        acc, precision,npv, sensitivity, specificity, mcc,f1 = utils.calculate_performace(len(y_class), y_class, y_test_tmp)
        sepscores.append([acc, precision,npv, sensitivity, specificity, mcc,f1,roc_auc])
        print('gcforest:acc=%f,precision=%f,npv=%f,sensitivity=%f,specificity=%f,mcc=%f,f1=%f,roc_auc=%f'
                 % (acc, precision,npv, sensitivity, specificity, mcc,f1, roc_auc))
    scores=np.array(sepscores)
    print("acc=%.2f%% (+/- %.2f%%)" % (np.mean(scores, axis=0)[0]*100,np.std(scores, axis=0)[0]*100))
    print("precision=%.2f%% (+/- %.2f%%)" % (np.mean(scores, axis=0)[1]*100,np.std(scores, axis=0)[1]*100))
    print("npv=%.2f%% (+/- %.2f%%)" % (np.mean(scores, axis=0)[2]*100,np.std(scores, axis=0)[2]*100))
    print("sensitivity=%.2f%% (+/- %.2f%%)" % (np.mean(scores, axis=0)[3]*100,np.std(scores, axis=0)[3]*100))
    print("specificity=%.2f%% (+/- %.2f%%)" % (np.mean(scores, axis=0)[4]*100,np.std(scores, axis=0)[4]*100))
    print("mcc=%.2f%% (+/- %.2f%%)" % (np.mean(scores, axis=0)[5]*100,np.std(scores, axis=0)[5]*100))
    print("f1=%.2f%% (+/- %.2f%%)" % (np.mean(scores, axis=0)[6]*100,np.std(scores, axis=0)[6]*100))
    print("roc_auc=%.2f%% (+/- %.2f%%)" % (np.mean(scores, axis=0)[7]*100,np.std(scores, axis=0)[7]*100))

    result1=np.mean(scores,axis=0)
    H1=result1.tolist()
    sepscores.append(H1)
    result=sepscores
    row=yscore.shape[0]
    #column=data.shape[1]
    yscore=yscore[np.array(range(1,row)),:]
    yscore_sum = pd.DataFrame(data=yscore)
    yscore_sum.to_csv('DeepForest_results\Drug_ACP_yscore.csv')
    ytest=ytest[np.array(range(1,row)),:]
    ytest_sum = pd.DataFrame(data=ytest)
    ytest_sum.to_csv('DeepForest_results\Drug_ACP_ytest.csv')
    fpr, tpr, _ = roc_curve(ytest[:,0], yscore[:,0])
    auc_score=np.mean(scores, axis=0)[7]
    #lw=2
    #plt.plot(fpr, tpr, color='darkorange',
    #lw=lw, label='ROC (area = %0.2f%%)' % auc_score)
    #plt.plot([0, 1], [0, 1], color='navy', lw=lw, linestyle='--')
    #plt.xlim([0.0, 1.05])
    #plt.ylim([0.0, 1.05])
    #plt.xlabel('False Positive Rate')
    #plt.ylabel('True Positive Rate')
    #plt.title('Receiver operating characteristic')
    #plt.legend(loc="lower right")
    #plt.show()
	
    colum = ['ACC', 'precision', 'npv', 'Sn', 'Sp', 'MCC', 'F1', 'AUC']
    ro = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11']
    data_csv = pd.DataFrame(columns=colum, data=result, index=ro)
    data_csv.to_csv('DeepForest_results\Drug_ACP_result.csv')
    #interval = (time.time() - start)
    #print("Time used:",interval)
def dumpmodel(X, y,gc):
     gc.fit_transform(X, y)

     with open("model_Drug_ACP_CDF.pkl", "wb") as f:
         pickle.dump(gc, f, pickle.HIGHEST_PROTOCOL)
     #with open("test.pkl", "wb") as f:
     #    pickle.dump(gcmodel, f, pickle.HIGHEST_PROTOCOL)
     #joblib.dump(svc, 'saved_model_PELM_RF.pkl')
     #pickle.dump(gcmodel, open("pima.pickle_model_PELM_S_SVM.dat", "wb"))
     print("Saved model to disk")

def indepTesting(Xtest, Ytest):
     Sepscores = []
     ytest = np.ones((1, 2)) * 0.5
     yscore = np.ones((1, 2)) * 0.5
     # xtest=np.asarray(pd.read_csv(Xtest).iloc[:].values)
     # ytest=np.asarray(pd.read_csv(Xtest).iloc[:].values.ravel())
     xtest = np.vstack(Xtest)
     y_test = np.vstack(Ytest)
     with open("model_Drug_ACP_CDF.pkl", "rb") as f:
         gc = pickle.load(f)
     y_score = gc.predict_proba(xtest)
     #ldmodel = pickle.load(open("pima.pickle_model_PELM_S_SVM.dat", "rb"))
     #y_score = ldmodel.predict_proba(xtest)
     #ldmodel = pickle.load(open("model/pima.pickle_model_PELM_S_SVM.dat", "rb"))
     #print("Loaded model from disk")
     #y_score = ldmodel.predict_proba(xtest)
     yscore = np.vstack((yscore, y_score))
     y_class = utils.categorical_probas_to_classes(y_score)

     fpr, tpr, _ = roc_curve(y_test, y_score[:, 1])
     roc_auc = auc(fpr, tpr)
     acc, precision, npv, sensitivity, specificity, mcc, f1 = utils.calculate_performace(len(y_class), y_class,
                                                                                         y_test)
     Sepscores.append([acc, precision,npv,sensitivity, specificity, mcc,f1,roc_auc])
     print('Deepgcforest:acc=%f,precision=%f,npv=%f,sensitivity=%f,specificity=%f,mcc=%f,f1=%f,roc_auc=%f'
           % (acc, precision, npv, sensitivity, specificity, mcc, f1, roc_auc))
     fpr, tpr, _ = roc_curve(y_test[:, 0], y_score[:, 1])
     auc_score = auc(fpr, tpr)
     scores = np.array(Sepscores)
     result1 = np.mean(scores, axis=0)
     H1 = result1.tolist()
     Sepscores.append(H1)
     result = Sepscores
     row = y_score.shape[0]
     yscore = y_score[np.array(range(1, row)), :]
     yscore_sum = pd.DataFrame(data=yscore)
     yscore_sum.to_csv('DeepForest_results\yscore_Drug_ACP_CDF_ind.csv')
     y_test = y_test[np.array(range(1, row)), :]
     ytest_sum = pd.DataFrame(data=y_test)
     ytest_sum.to_csv('DeepForest_results\ytest_Drug_ACP_CDF_ind.csv')
     colum = ['ACC', 'precision', 'npv', 'Sn', 'Sp', 'MCC', 'F1', 'AUC']
     # ro = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11']
     data_csv = pd.DataFrame(columns=colum, data=result)  # , index=ro)
     data_csv.to_csv('DeepForest_results\Results_Drug_ACP_ind.csv')
     lw = 2
     plt.plot(fpr, tpr, color='darkorange',
              lw=lw, label='SVC ROC (area = %0.2f%%)' % auc_score)
     plt.plot([0, 1], [0, 1], color='navy', lw=lw, linestyle='--')
     plt.xlim([0.0, 1.05])
     plt.ylim([0.0, 1.05])
     plt.xlabel('False Positive Rate')
     plt.ylabel('True Positive Rate')
     plt.title('Receiver operating characteristic')
     plt.legend(loc="lower right")
     plt.grid()
     plt.show()
if __name__ == "__main__":
    #start=time.time()
    config = get_toy_config()
    gc = GCForest(config)
    #get_data(gc)
    ###data for training#######S_serevsiea_KgapedFeat'
    #data_train = sio.loadmat('name.mat')
    #data_train = data_train.get('name')
    #label1 = np.ones((300, 1))  # Value can be changed
    #label2 = np.zeros((291, 1))
    #label = np.append(label1, label2)
    #Zscore_data=stats.zscore(data1)
    #data_1 = pd.read_csv(r'ALL_S_cerevsiea_indpendent.csv', header=None)
    #data3 = np.array(data_1)
    #data_4,importance=lassodimension(data2,label,alpha=np.array([0.0002, 0.002, 0.003,0.004, 0.005, 0.006, 0.007, 0.008,0.009]))#, 0.01,0.02,0.03,0.04,0.05]))
    #data_5, importance = elasticNet(data2, label, alpha=np.array([0.001, 0.002, 0.003,0.004, 0.005, 0.006, 0.007, 0.008,0.009, 0.01,0.02,0.03,0.04,0.05]))
    #data_csv = pd.DataFrame(data=data_5)
   # data_csv.to_csv('Enh_nonEnh_NCP_CKNSAP_1L_Enet.csv')
    #new_data = data3[:, importance]
    #data_csv = pd.DataFrame(data=new_data)
    #data_csv.to_csv('ALL_S_cerevsiea_indpendent.csv')
    # data_3=LOG_RFE_selection(100,data2,label)
    # data_4=selectFromLinearSVC(data2,label,1.5)#
    # data_6=SVM_RFE_selection(100,data2,label)
    # data_5=XGB_selection(100,data2,label)
    #data_6 = LGBM_RFE(300, data2, label)
    #data_csv = pd.DataFrame(data=data_6)
    #data_csv.to_csv('Train_1L_LGBM_RFE_300.csv')
    # data_7=GDB_RFE(100,data2,label)
    scale_data = scale(data_train)
    #MinMax = MinMaxScaler(feature_range=((0, 1)))
    #MinMaxdata = MinMax.fit_transform(data_6)
    #Norm_data=minmax_scale(data2)
    #data_normalized = normalize(data2, norm='l1')
    X = scale_data
    y = label
    ############data for testing#############
    #x_test = sio.loadmat('test.mat')
    #X_test = data_test.get('test')
    #indpendent_data=scale(data_test)
    
    #importance_indexes = pd.read_csv(r'importance_indpendent_net.csv')
    #importance=importance_indexes[:,1]
    #new_data = data1[:, importance]
    #label1_test = np.ones((76, 1))  # Value can be changed
    #label2_test = np.zeros((73, 1))
    label_test = np.append(label1_test, label2_test)
    indepXtest = indpendent_data
    indepYtest = label_test
     #########function calling###########
    training(X, y,gc)
    indepTesting(indepXtest, indepYtest)
    interval = (time.time() - start)
    print("Time used:", interval)
